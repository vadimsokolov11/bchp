<?php

$title = 'Страницы';
ob_start(); 
?>


<section
      id="page-banner"
      class="pt-200 pb-150 bg_cover"
      style="background-image: url(public/images//page-banner.jpg)"
    >
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="page-banner-content">
              <h3>Наши услуги</h3>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!--====== PAGE BANNER PART ENDS ======-->

    <!--====== PRODUCTS PART START ======-->

    <section id="products-part" class="pt-65">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="section-title text-center pb-15">
              <h2>Услуги по Бурению и Водоснабжению</h2>
              <ul>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
              </ul>
              <p>
                Решения в бурении и обустройстве скважин. Гарантированное
                водоснабжение для домов, предприятий и коммерческих объектов.
                Обеспечиваем надежные источники воды под ключ
              </p>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="products-slied owl-carousel">
            <div class="col-lg-12">
              <div class="singel-products mt-30">
                <div class="products-image">
                  <img src="public/images//product/p-1.jpg" alt="Products" />
                </div>
                <div class="products-contant">
                  <h6 class="products-title">
                    <a href="#">Бурение на песок и артезианских скважин</a>
                  </h6>
                  <div class="price-rating d-flex justify-content-between">
                    <div class="price">
                      <span class="regular-price" style="font-size: 15px"
                        >Цена по запросу</span
                      >
                    </div>
                  </div>
                  <p class="text">
                    Глубина до 200 метров. Стабильное водоснабжение
                  </p>
                  <div class="products-cart">
                    <a class="cart-add" href="#order">Заказать</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-12">
              <div class="singel-products mt-30">
                <div class="products-image">
                  <img src="public/images//product/p-2.jpg" alt="Products" />
                </div>
                <div class="products-contant">
                  <h6 class="products-title">
                    <a href="#">Проведение разведочного бурения</a>
                  </h6>
                  <div class="price-rating d-flex justify-content-between">
                    <div class="price">
                      <span class="regular-price" style="font-size: 15px"
                        >Цена по запросу</span
                      >
                    </div>
                  </div>
                  <p class="text">
                    Определение геологических характеристик. Точное планирование
                    бурения
                  </p>
                  <div class="products-cart">
                    <a class="cart-add" href="#order">Заказать</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-12">
              <div class="singel-products mt-30">
                <div class="products-image">
                  <img src="public/images//product/p-3.jpg" alt="Products" />
                </div>
                <div class="products-contant">
                  <h6 class="products-title">
                    <a href="#">Подготовка технической документации</a>
                  </h6>
                  <div class="price-rating d-flex justify-content-between">
                    <div class="price">
                      <span class="regular-price" style="font-size: 15px"
                        >Цена по запросу</span
                      >
                    </div>
                  </div>
                  <p class="text">
                    Ведение бурового журнала. Комплектация техническими
                    документами
                  </p>
                  <div class="products-cart">
                    <a class="cart-add" href="#order">Заказать</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-12">
              <div class="singel-products mt-30">
                <div class="products-image">
                  <img src="public/images//product/p-4.jpg" alt="Products" />
                </div>
                <div class="products-contant">
                  <h6 class="products-title">
                    <a href="#">Бурение на воду</a>
                  </h6>
                  <div class="price-rating d-flex justify-content-between">
                    <div class="price">
                      <span class="regular-price" style="font-size: 15px"
                        >Цена по запросу</span
                      >
                    </div>
                  </div>
                  <p class="text">
                    Для частных, коллективных и промышленных нужд. Соблюдение
                    стандартов качества воды
                  </p>
                  <div class="products-cart">
                    <a class="cart-add" href="#order">Заказать</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-12">
              <div class="singel-products mt-30">
                <div class="products-image">
                  <img src="public/images//product/p-5.jpg" alt="Products" />
                </div>
                <div class="products-contant">
                  <h6 class="products-title">
                    <a href="#">Обустройство скважины под ключ</a>
                  </h6>
                  <div class="price-rating d-flex justify-content-between">
                    <div class="price">
                      <span class="regular-price" style="font-size: 15px"
                        >Цена по запросу</span
                      >
                    </div>
                  </div>
                  <p class="text">
                    Всеэтапное обеспечение работ. Гарантия функционирования
                  </p>
                  <div class="products-cart">
                    <a class="cart-add" href="#order">Заказать</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-12">
              <div class="singel-products mt-30">
                <div class="products-image">
                  <img src="public/images//product/p-6.jpg" alt="Products" />
                </div>
                <div class="products-contant">
                  <h6 class="products-title">
                    <a href="#">Чистка и ремонт скважин</a>
                  </h6>
                  <div class="price-rating d-flex justify-content-between">
                    <div class="price">
                      <span class="regular-price" style="font-size: 15px"
                        >Цена по запросу</span
                      >
                    </div>
                  </div>
                  <p class="text">
                    Профессиональная очистка. Ремонт с минимальными простоями
                  </p>
                  <div class="products-cart">
                    <a class="cart-add" href="#order">Заказать</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-12">
              <div class="singel-products mt-30">
                <div class="products-image">
                  <img src="public/images//product/p-7.jpg" alt="Products" />
                </div>
                <div class="products-contant">
                  <h6 class="products-title">
                    <a href="#">Водоснабжение загородных домов</a>
                  </h6>
                  <div class="price-rating d-flex justify-content-between">
                    <div class="price">
                      <span class="regular-price" style="font-size: 15px"
                        >Цена по запросу</span
                      >
                    </div>
                  </div>
                  <p class="text">Экономия водных ресурсов</p>
                  <div class="products-cart">
                    <a class="cart-add" href="#order">Заказать</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-12">
              <div class="singel-products mt-30">
                <div class="products-image">
                  <img src="public/images//product/p-8.jpg" alt="Products" />
                </div>
                <div class="products-contant">
                  <h6 class="products-title">
                    <a href="#">Бурение колодцев</a>
                  </h6>
                  <div class="price-rating d-flex justify-content-between">
                    <div class="price">
                      <span class="regular-price" style="font-size: 15px"
                        >Цена по запросу</span
                      >
                    </div>
                  </div>
                  <p class="text">Гарантированное водоснабжение</p>
                  <div class="products-cart">
                    <a class="cart-add" href="#order">Заказать</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!--====== PRODUCTS PART ENDS ======-->

    <!--====== PRICING PART START ======-->

    <section id="pricing-part" class="pt-70 pb-80">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="section-title text-center pb-15">
              <h2>Услуги по бурению и обустройству скважин</h2>
              <ul>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
              </ul>
              <p>
                Выбирайте услуги с прозрачной ценовой политикой для
                водоснабжения и обустройства скважин. Ценами за каждый метр
                обеспечиваемого водопровода
              </p>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-6 col-md-6">
            <div class="singel-pricing gray-bg text-center mt-30">
              <h4>обустройство скважин</h4>
              <h3>от 50 т.р.</h3>
              <ul>
                <li>Постоянный поток чистой воды</li>
                <li>Регулирование давления</li>
                <li>Фильтрация и обеззараживание</li>
                <li>Регулярная проверка воды 1-й год</li>
              </ul>
              <a href="contact.html">Заказать сейчас</a>
            </div>
          </div>
          <div class="col-lg-6 col-md-6">
            <div class="singel-pricing gray-bg text-center mt-30">
              <h4>бурение скважин</h4>
              <h3>2 т.р за М/2</h3>
              <ul>
                <li>Оптимальный выбор водносного слоя</li>
                <li>Бурение в течении 2 дней</li>
                <li>Технические проверки в первый год</li>
                <li>Гарантия 5 лет</li>
              </ul>
              <a href="contact.html">Заказать сейчас</a>
            </div>
          </div>
          <div class="col-lg-6 col-md-6">
            <div class="singel-pricing gray-bg text-center mt-30">
              <h4>бурение колодцев</h4>
              <h3>2.5 т.р за М/2</h3>
              <ul>
                <li>Глубокое бурение - до 200 метров</li>
                <li>Точность попадания водоносного слоя - 95%</li>
                <li>Начнем через 3 дня</li>
                <li>Гарантия 5 лет</li>
              </ul>
              <a href="contact.html">Заказать сейчас</a>
            </div>
          </div>
          <div class="col-lg-6 col-md-8">
            <div class="singel-pricing gray-bg text-center mt-30">
              <h4 style="text-align: center">водоснабжение</h4>
              <h3>3 т.р за М/2</h3>
              <ul>
                <li>Увеличение объема воды на 30% после обустройства</li>
                <li>Гарантия на 5 лет</li>
                <li>Начало работ через 2 дня</li>
                <li>10 лет опыта</li>
              </ul>
              <a href="contact.html">Заказать сейчас</a>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!--====== PRICING PART ENDS ======-->

    <!--====== CLIENT PART START ======-->

    <section id="client-part" class="pt-80">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="section-title text-center">
              <img src="public/images//client/c.png" alt="icon" />
              <h2>Отзывы наших клиентов</h2>
              <ul>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
              </ul>
              <p>
                Лучший показатель качества – довольные клиенты. В этом разделе
                вы найдете реальные отзывы о наших услугах по бурению и
                обустройству скважин. Доверьтесь опыту тех, кто уже оценил наш
                профессионализм и эффективность. Ваше доверие – наша ценность, и
                мы гордимся нашими успешными проектами, созданными вместе с вами
              </p>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="client-slied owl-carousel">
            <div class="col-lg-12">
              <div class="singel-client mt-50">
                <div class="client-thum">
                  <div class="client-img">
                    <img src="public/images//client/c-1.jpg" alt="Client" />
                  </div>
                  <div class="client-head">
                    <h5>Ирина Соколова</h5>
                  </div>
                </div>
                <div class="client-text mt-35">
                  <p>
                    Сотрудничество с вашей компанией - это просто находка!
                    Профессионализм, оперативность и качество работы - именно
                    то, что мы оцениваем. Спасибо за глубокое бурение и
                    стабильное водоснабжение. Рекомендую!
                  </p>
                </div>
              </div>
            </div>
            <div class="col-lg-12">
              <div class="singel-client mt-50">
                <div class="client-thum">
                  <div class="client-img">
                    <img src="public/images//client/c-2.jpg" alt="Client" />
                  </div>
                  <div class="client-head">
                    <h5>Александр Петров</h5>
                  </div>
                </div>
                <div class="client-text mt-35">
                  <p>
                    Был приятно удивлен вашим сервисом. От начала до конца -
                    четко и по делу. Бурение проведено на высшем уровне, а
                    обслуживание после установки скважины оставило только
                    положительные впечатления. Спасибо за качество и
                    профессионализм!
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!--====== CLIENT PART ENDS ======-->

    <!--====== BRAND PART START ======-->

    <section id="brand-part" class="pt-70 pb-80"></section>

    <!--====== BRAND PART ENDS ======-->

    <!--====== DELIVERY PART START ======-->

    <section
      id="delivery-part"
      class="delivery-part-2 bg_cover pt-95 pb-100"
      data-overlay="8"
      style="background-image: url(public/images//bg-2.jpg)"
    >
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-7 offset-xl-1">
            <div class="delivery-text text-center pb-30">
              <h2>Бурение - Пробурим до самых Истоков</h2>
              <p>
                Откройте новые горизонты водоснабжения с нашими услугами по
                бурению. Гарантируем глубокое проникновение в земные слои,
                обеспечивая стабильный и долгосрочный источник чистой воды.
                Возложите доверие на наш опыт
              </p>
              <a href="contact.html">Узнать больше</a>
            </div>
          </div>
        </div>
      </div>
      <div class="delivery-image d-none d-lg-flex align-items-end">
        <img src="public/images//delivery-van.jpg" alt="Iamge" />
      </div>
    </section>
<?php $content = ob_get_clean(); 

include 'app/views/layout/layout_user.php';
?>