<?php


ob_start(); 
?>


<section
      id="page-banner"
      class="pt-200 pb-150 bg_cover"
      style="background-image: url(public/images/page-banner.jpg)"
    >
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="page-banner-content">
              <h3>Новости</h3>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!--====== PAGE BANNER PART ENDS ======-->

    <!--====== BLOG PART START ======-->

    <section id="blog-part" class="pt-65">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="section-title text-center pb-15">
              <h2>Свежие Новости</h2>
              <ul>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
              </ul>
              <p>
                Последние обновления в мире компании. Поддерживаем в курсе новых
                разработок, технологических инноваций и успешных проектов.
                Оставайтесь в центре происходящего с свежими новостями, и будьте
                в курсе того, как мы продолжаем обеспечивать надежное
                водоснабжение для клиентов
              </p>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-4 col-md-6">
            <div class="singel-blog mt-30">
              <div class="blog-thum">
                <img src="public/images/blog/b-1.jpg" alt="Blog" />
                <div class="date text-center">
                  <h3>22</h3>
                  <span>Сентябрь 2022</span>
                </div>
              </div>
              <div class="blog-cont pt-25">
                <a href="#"
                  ><h5>Новое Оборудование для Эффективного Бурения</h5></a
                >
                <p>
                  Развитие наших технологий: представляем современное буровое
                  оборудование для повышения эффективности и точности бурения
                  скважин
                </p>
                <a href="#">Подробнее</a>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="singel-blog mt-30">
              <div class="blog-thum">
                <img src="public/images/blog/b-2.jpg" alt="Blog" />
                <div class="date text-center">
                  <h3>22</h3>
                  <span>Сентябрь 2022</span>
                </div>
              </div>
              <div class="blog-cont pt-25">
                <a href="#"
                  ><h5>
                    Экологичность в Действии: Наш Вклад в Сохранение Природы
                  </h5></a
                >
                <p>
                  Мы в ответе за окружающую среду: узнайте о инициативах и
                  технологиях, направленных на минимизацию воздействия на
                  природу при проведении бурения
                </p>
                <a href="#">Подробнее</a>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="singel-blog mt-30">
              <div class="blog-thum">
                <img src="public/images/blog/b-3.jpg" alt="Blog" />
                <div class="date text-center">
                  <h3>22</h3>
                  <span>Сентябрь 2022</span>
                </div>
              </div>
              <div class="blog-cont pt-25">
                <a href="#"
                  ><h5>
                    Проекты Успеха: Реальные Решения для Надежного Водоснабжения
                  </h5></a
                >
                <p>
                  Поделимся историями успеха: узнайте о недавно завершенных
                  проектах по бурению и обустройству скважин, обеспечивающих
                  клиентов долгосрочным водоснабжением
                </p>
                <a href="#">Подробнее</a>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="singel-blog mt-30">
              <div class="blog-thum">
                <img src="public/images/blog/b-3.jpg" alt="Blog" />
                <div class="date text-center">
                  <h3>22</h3>
                  <span>Сентябрь 2022</span>
                </div>
              </div>
              <div class="blog-cont pt-25">
                <a href="#"
                  ><h5>
                    Проекты Успеха: Реальные Решения для Надежного Водоснабжения
                  </h5></a
                >
                <p>
                  Поделимся историями успеха: узнайте о недавно завершенных
                  проектах по бурению и обустройству скважин, обеспечивающих
                  клиентов долгосрочным водоснабжением
                </p>
                <a href="#">Подробнее</a>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="singel-blog mt-30">
              <div class="blog-thum">
                <img src="public/images/blog/b-3.jpg" alt="Blog" />
                <div class="date text-center">
                  <h3>22</h3>
                  <span>Сентябрь 2022</span>
                </div>
              </div>
              <div class="blog-cont pt-25">
                <a href="#"
                  ><h5>
                    Проекты Успеха: Реальные Решения для Надежного Водоснабжения
                  </h5></a
                >
                <p>
                  Поделимся историями успеха: узнайте о недавно завершенных
                  проектах по бурению и обустройству скважин, обеспечивающих
                  клиентов долгосрочным водоснабжением
                </p>
                <a href="#">Подробнее</a>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="singel-blog mt-30">
              <div class="blog-thum">
                <img src="public/images/blog/b-3.jpg" alt="Blog" />
                <div class="date text-center">
                  <h3>22</h3>
                  <span>Сентябрь 2022</span>
                </div>
              </div>
              <div class="blog-cont pt-25">
                <a href="#"
                  ><h5>
                    Проекты Успеха: Реальные Решения для Надежного Водоснабжения
                  </h5></a
                >
                <p>
                  Поделимся историями успеха: узнайте о недавно завершенных
                  проектах по бурению и обустройству скважин, обеспечивающих
                  клиентов долгосрочным водоснабжением
                </p>
                <a href="#">Подробнее</a>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="singel-blog mt-30">
              <div class="blog-thum">
                <img src="public/images/blog/b-3.jpg" alt="Blog" />
                <div class="date text-center">
                  <h3>22</h3>
                  <span>Сентябрь 2022</span>
                </div>
              </div>
              <div class="blog-cont pt-25">
                <a href="#"
                  ><h5>
                    Проекты Успеха: Реальные Решения для Надежного Водоснабжения
                  </h5></a
                >
                <p>
                  Поделимся историями успеха: узнайте о недавно завершенных
                  проектах по бурению и обустройству скважин, обеспечивающих
                  клиентов долгосрочным водоснабжением
                </p>
                <a href="#">Подробнее</a>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="singel-blog mt-30">
              <div class="blog-thum">
                <img src="public/images/blog/b-3.jpg" alt="Blog" />
                <div class="date text-center">
                  <h3>22</h3>
                  <span>Сентябрь 2022</span>
                </div>
              </div>
              <div class="blog-cont pt-25">
                <a href="#"
                  ><h5>
                    Проекты Успеха: Реальные Решения для Надежного Водоснабжения
                  </h5></a
                >
                <p>
                  Поделимся историями успеха: узнайте о недавно завершенных
                  проектах по бурению и обустройству скважин, обеспечивающих
                  клиентов долгосрочным водоснабжением
                </p>
                <a href="#">Подробнее</a>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="singel-blog mt-30">
              <div class="blog-thum">
                <img src="public/images/blog/b-3.jpg" alt="Blog" />
                <div class="date text-center">
                  <h3>22</h3>
                  <span>Сентябрь 2022</span>
                </div>
              </div>
              <div class="blog-cont pt-25">
                <a href="#"
                  ><h5>
                    Проекты Успеха: Реальные Решения для Надежного Водоснабжения
                  </h5></a
                >
                <p>
                  Поделимся историями успеха: узнайте о недавно завершенных
                  проектах по бурению и обустройству скважин, обеспечивающих
                  клиентов долгосрочным водоснабжением
                </p>
                <a href="#">Подробнее</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!--====== BLOG PART ENDS ======-->

    <!--====== BRAND PART START ======-->

    <section id="brand-part" class="pt-65 pb-80"></section>

    <!--====== BRAND PART ENDS ======-->

    <!--====== DELIVERY PART START ======-->

    <section
      id="delivery-part"
      class="delivery-part-2 bg_cover pt-95 pb-100"
      data-overlay="8"
      style="background-image: url(public/images/bg-2.jpg)"
    >
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-7 offset-xl-1">
            <div class="delivery-text text-center pb-30">
              <h2>Бурение - Пробурим до самых Истоков</h2>
              <p>
                Откройте новые горизонты водоснабжения с нашими услугами по
                бурению. Гарантируем глубокое проникновение в земные слои,
                обеспечивая стабильный и долгосрочный источник чистой воды.
                Возложите доверие на наш опыт
              </p>
              <a href="contact.html">Узнать больше</a>
            </div>
          </div>
        </div>
      </div>
      <div class="delivery-image d-none d-lg-flex align-items-end">
        <img src="public/images/delivery-van.jpg" alt="Iamge" />
      </div>
    </section>
<?php $content = ob_get_clean(); 

include 'app/views/layout/layout_user.php';
?>