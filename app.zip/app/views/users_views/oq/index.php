<?php


ob_start(); 
?>

<section
      id="page-banner"
      class="pt-200 pb-150 bg_cover"
      style="background-image: url(public/images/page-banner.jpg)"
    >
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="page-banner-content">
              <h3>Вопрос-ответ</h3>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!--====== PAGE BANNER PART ENDS ======-->

    <!--====== FAQ PAGE PART START ======-->

    <section id="faq-page" class="pt-60">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="section-title text-center">
              <h2>Разъяснения по часто задаваемым вопросам от клиентов</h2>
              <ul>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
              </ul>
              <p>
                Цель - предоставить информацию о услугах. Если у вас остались
                вопросы, не найденные в этом разделе, не стесняйтесь связаться
                нашей команде. Готовы помочь в вопросах, связанных с бурением и
                обустройством
              </p>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
            <div class="faq-page-content pt-45">
              <div class="accordion" id="accordionExample">
                <div class="card">
                  <div class="card-header" id="headingOne">
                    <h5>
                      <a
                        href="#"
                        class="collapsed"
                        data-toggle="collapse"
                        data-target="#collapseOne"
                        aria-expanded="true"
                        aria-controls="collapseOne"
                      >
                        <span>Какова глубина скважин, которые вы бурите?</span>
                      </a>
                    </h5>
                  </div>

                  <div
                    id="collapseOne"
                    class="collapse"
                    aria-labelledby="headingOne"
                    data-parent="#accordionExample"
                  >
                    <div class="card-body">
                      <p>
                        Глубина скважин, которые мы бурим, зависит от
                        индивидуальных требований и геологических особенностей
                        местности. Мы осуществляем бурение на различные глубины,
                        включая поверхностные и глубокие артезианские скважины,
                        обеспечивая стабильный и качественный водный ресурс для
                        наших клиентов. Для конкретной информации по вашему
                        проекту свяжитесь с нами, и мы с удовольствием
                        предоставим подробности.
                      </p>
                    </div>
                  </div>
                </div>

                <div class="card">
                  <div class="card-header" id="headingTwo">
                    <h5>
                      <a
                        href="#"
                        class="collapsed"
                        data-toggle="collapse"
                        data-target="#collapseTwo"
                        aria-expanded="false"
                        aria-controls="collapseTwo"
                      >
                        <span
                          >Какие технологии вы используете для обеспечения
                          качественного водоснабжения?</span
                        >
                      </a>
                    </h5>
                  </div>
                  <div
                    id="collapseTwo"
                    class="collapse"
                    aria-labelledby="headingTwo"
                    data-parent="#accordionExample"
                  >
                    <div class="card-body">
                      <p>
                        Для обеспечения качественного водоснабжения мы
                        используем современные технологии бурения и обустройства
                        скважин. Это включает в себя применение высокоточного
                        бурового оборудования, гидрогеологических исследований,
                        а также тщательный анализ геологических характеристик
                        местности. Наши специалисты следят за соблюдением
                        стандартов качества воды и применяют передовые методы
                        очистки и дезинфекции, гарантируя безопасность и чистоту
                        вашего водоснабжения.
                      </p>
                    </div>
                  </div>
                </div>

                <div class="card">
                  <div class="card-header" id="headingThree">
                    <h5>
                      <a
                        href="#"
                        class=""
                        data-toggle="collapse"
                        data-target="#collapseThree"
                        aria-expanded="false"
                        aria-controls="collapseThree"
                        ><span
                          >Сколько времени занимает процесс бурения и
                          обустройства скважины?</span
                        ></a
                      >
                    </h5>
                  </div>
                  <div
                    id="collapseThree"
                    class="collapse show"
                    aria-labelledby="headingThree"
                    data-parent="#accordionExample"
                  >
                    <div class="card-body">
                      <p>
                        Время, необходимое для завершения процесса бурения и
                        обустройства скважины, может варьироваться в зависимости
                        от нескольких факторов, включая глубину бурения,
                        геологические характеристики местности и объем
                        предстоящих работ. Обычно, с момента начала бурения до
                        завершения обустройства, процесс занимает от нескольких
                        дней до нескольких недель. Для получения более точной
                        информации и оценки времени выполнения работ,
                        рекомендуем связаться с нашими специалистами, которые
                        проведут подробную консультацию и оценку вашего проекта.
                      </p>
                    </div>
                  </div>
                </div>

                <div class="card">
                  <div class="card-header" id="headingFore">
                    <h5>
                      <a
                        href="#"
                        class="collapsed"
                        data-toggle="collapse"
                        data-target="#collapseFore"
                        aria-expanded="false"
                        aria-controls="collapseThree"
                      >
                        <span
                          >Какие гарантии предоставляются на ваши услуги?</span
                        >
                      </a>
                    </h5>
                  </div>
                  <div
                    id="collapseFore"
                    class="collapse"
                    aria-labelledby="headingThree"
                    data-parent="#accordionExample"
                  >
                    <div class="card-body">
                      <p>
                        Мы предоставляем гарантии на все наши услуги в
                        соответствии с законодательством и стандартами качества.
                        Гарантийные условия могут различаться в зависимости от
                        характера выполняемых работ и используемых материалов.
                        Обычно, мы предоставляем гарантию на бурение скважин и
                        обустройство на определенный период времени, который
                        будет детализирован в договоре. Гарантия
                        распространяется на качество выполненных работ и
                        работоспособность скважины. Подробные условия гарантии
                        всегда обсуждаются с клиентом перед началом работ.
                      </p>
                    </div>
                  </div>
                </div>

                <div class="card">
                  <div class="card-header" id="headingFive">
                    <h5>
                      <a
                        href="#"
                        class="collapsed"
                        data-toggle="collapse"
                        data-target="#collapseFive"
                        aria-expanded="false"
                        aria-controls="collapseThree"
                      >
                        <span
                          >Можете ли вы помочь с анализом воды после
                          обустройства скважины?</span
                        >
                      </a>
                    </h5>
                  </div>
                  <div
                    id="collapseFive"
                    class="collapse"
                    aria-labelledby="headingThree"
                    data-parent="#accordionExample"
                  >
                    <div class="card-body">
                      <p>
                        Да, мы предоставляем услуги анализа воды после
                        обустройства скважины. Этот этап является важной частью
                        наших услуг, поскольку он гарантирует, что вода
                        соответствует необходимым стандартам качества. Наши
                        специалисты проведут необходимые тесты на содержание
                        вредных веществ, микроорганизмов и других параметров,
                        чтобы удостовериться в чистоте и безопасности вашего
                        водоснабжения. Получив результаты анализа, мы
                        предоставим вам подробную информацию и, при
                        необходимости, рекомендации по дополнительным мерам
                        обработки воды.
                      </p>
                    </div>
                  </div>
                </div>

                <div class="card">
                  <div class="card-header" id="headingSix">
                    <h5>
                      <a
                        href="#"
                        class="collapsed"
                        data-toggle="collapse"
                        data-target="#collapseSix"
                        aria-expanded="false"
                        aria-controls="collapseThree"
                      >
                        <span
                          >Какие дополнительные услуги предлагаете для
                          поддержания работоспособности скважины?</span
                        >
                      </a>
                    </h5>
                  </div>
                  <div
                    id="collapseSix"
                    class="collapse"
                    aria-labelledby="headingThree"
                    data-parent="#accordionExample"
                  >
                    <div class="card-body">
                      <p>
                        Помимо бурения и обустройства скважин, мы предоставляем
                        комплекс дополнительных услуг для поддержания и
                        эффективной работы вашей скважины. Это включает в себя
                        регулярное техническое обслуживание, чистку и ремонт
                        скважин, обновление оборудования, установку следящих
                        систем и обучение владельцев. Наша цель - обеспечить вам
                        не только качественное водоснабжение, но и долгосрочную
                        надежность вашей скважины.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!--====== FAQ PAGE PART ENDS ======-->

    <!--====== CLIENT PART START ======-->

    <section id="client-part" class="pt-70">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="section-title text-center">
              <img src="public/images/client/c.png" alt="icon" />
              <h2>Отзывы наших клиентов</h2>
              <ul>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
              </ul>
              <p>
                Лучший показатель качества – довольные клиенты. В этом разделе
                вы найдете реальные отзывы о наших услугах по бурению и
                обустройству скважин. Доверьтесь опыту тех, кто уже оценил наш
                профессионализм и эффективность. Ваше доверие – наша ценность, и
                мы гордимся нашими успешными проектами, созданными вместе с вами
              </p>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="client-slied owl-carousel">
            <div class="col-lg-12">
              <div class="singel-client mt-50">
                <div class="client-thum">
                  <div class="client-img">
                    <img src="public/images/client/c-1.jpg" alt="Client" />
                  </div>
                  <div class="client-head">
                    <h5>Ирина Соколова</h5>
                  </div>
                </div>
                <div class="client-text mt-35">
                  <p>
                    Сотрудничество с вашей компанией - это просто находка!
                    Профессионализм, оперативность и качество работы - именно
                    то, что мы оцениваем. Спасибо за глубокое бурение и
                    стабильное водоснабжение. Рекомендую!
                  </p>
                </div>
              </div>
            </div>
            <div class="col-lg-12">
              <div class="singel-client mt-50">
                <div class="client-thum">
                  <div class="client-img">
                    <img src="public/images/client/c-2.jpg" alt="Client" />
                  </div>
                  <div class="client-head">
                    <h5>Александр Петров</h5>
                  </div>
                </div>
                <div class="client-text mt-35">
                  <p>
                    Был приятно удивлен вашим сервисом. От начала до конца -
                    четко и по делу. Бурение проведено на высшем уровне, а
                    обслуживание после установки скважины оставило только
                    положительные впечатления. Спасибо за качество и
                    профессионализм!
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!--====== CLIENT PART ENDS ======-->

    <!--====== BRAND PART START ======-->

    <section id="brand-part" class="pt-70 pb-80"></section>

    <!--====== BRAND PART ENDS ======-->

    <!--====== DELIVERY PART START ======-->

    <section
      id="delivery-part"
      class="delivery-part-2 bg_cover pt-95 pb-100"
      data-overlay="8"
      style="background-image: url(public/images/bg-2.jpg)"
    >
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-7 offset-xl-1">
            <div class="delivery-text text-center pb-30">
              <h2>Бурение - Пробурим до самых Истоков</h2>
              <p>
                Откройте новые горизонты водоснабжения с нашими услугами по
                бурению. Гарантируем глубокое проникновение в земные слои,
                обеспечивая стабильный и долгосрочный источник чистой воды.
                Возложите доверие на наш опыт
              </p>
              <a href="contact.html">Узнать больше</a>
            </div>
          </div>
        </div>
      </div>
      <div class="delivery-image d-none d-lg-flex align-items-end">
        <img src="public/images/delivery-van.jpg" alt="Iamge" />
      </div>
    </section>
<?php $content = ob_get_clean(); 

include 'app/views/layout/layout_user.php';
?>