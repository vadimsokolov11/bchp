/*
 Template Name: Scoxe - Admin & Dashboard Template
 Author: Myra Studio
 File: Knob Chart
*/


$(function () {
  $('[data-plugin="knob"]').knob();
});