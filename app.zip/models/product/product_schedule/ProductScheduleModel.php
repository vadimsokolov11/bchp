<?php
namespace models\product\product_schedule;

use models\Database;
use models\monitoring\MonitoringModel;
use models\machine\spravka_machine\SpravkaMachineModel;
use models\product\spravka_product\SpravkaProductModel;
use models\report\ReportModel;

class ProductScheduleModel
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();

        try {
            $result = $this->db->query("SELECT 1 FROM `product_schedule` LIMIT 1");
        } catch (\PDOException $e) {
            $this->createTable();
        }
    }

    // Создание таблицы если ее нет в БД
    public function createTable()
    {

        $productScheduleTableQuery = "CREATE TABLE IF NOT EXISTS `product_schedule` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `date` TEXT,
            `whom` INT(11), -- кому предназначен для просмотра
            `provided_whom` INT(11), -- кем составлен
            `schedule` LONGTEXT, 
            `shedule_update` LONGTEXT, 
            `plan_beginning_month` LONGTEXT, 
            `machine` LONGTEXT, 
            `plan_month` TINYTEXT, -- план на месяц
            `fackt_month` TINYTEXT, -- факт за месяц
            `variance` TINYTEXT, -- разница между планом и фактом за месяц
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            FOREIGN KEY (`whom`) REFERENCES `users`(`id`),
            FOREIGN KEY (`provided_whom`) REFERENCES `users`(`id`)
        )";

        try {
            $this->db->exec($productScheduleTableQuery);
            return true;
        } catch (\PDOException $e) {
            return false;
        }
    }

    // Метод для вывода графика производства продукции с датой, фио тем кому на подпись и кто отправил на подпись
    public function getAllProductSchedule()
    {
        try {
            $stmt = $this->db->query("SELECT product_schedule.*, date, users_1.surname as whom, users_2.surname as provided_whom 
            FROM product_schedule 
            JOIN users AS users_1 ON product_schedule.whom = users_1.id 
            JOIN users AS users_2 ON product_schedule.provided_whom = users_2.id 
            ORDER BY `product_schedule`.`created_at` DESC;");

            $productSchedule = [];
            while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
                $productSchedule[] = $row;
            }
            return $productSchedule;
        } catch (\PDOException $e) {
            return false;
        }
    }


    // Метод на вывод всей информации месячного графика плана, кроме json массива
    public function getSheduleInfoById($id)
    {
        $query = "SELECT product_schedule.id, date, users_1.surname as surname_whom, 
        CONCAT(LEFT(users_1.name, 1), '.') as name_whom, 
        CONCAT(LEFT(users_1.patronymic, 1), '.') as patronymic_whom, 
        users_2.surname as surname_provided_whom, 
        CONCAT(LEFT(users_2.name, 1), '.') as name_provided_whom, 
        CONCAT(LEFT(users_2.patronymic, 1), '.') as patronymic_provided_whom, 
        plan_month, fackt_month, variance 
        FROM product_schedule 
        JOIN users AS users_1 ON product_schedule.whom = users_1.id 
        JOIN users AS users_2 ON product_schedule.provided_whom = users_2.id 
        WHERE product_schedule.id = ?;";

        try {
            $stmt = $this->db->prepare($query);
            $stmt->execute([$id]);
            $info = $stmt->fetch(\PDO::FETCH_ASSOC);
            return $info ? $info : false;
        } catch (\PDOException $e) {
            return false;
        }
    }

    // выводит инфу о месячном графике полностью
    // public function machineModel()
    // {

    //     $machineModel = new SpravkaMachineModel();
    //     $machine = $machineModel->getAllMachineWith();

    //     return $machine;

    // }
    // Метод для вывода данных из json массива и даты из таблицы месячного плана по id 
    public function getSheduleById($id)
    {
        // Модель с выводом всей информации о продукции
        $productModel = new SpravkaProductModel();
        $product = $productModel->getAllSpravkaProduct();




        $query = "SELECT id, date, whom, provided_whom, schedule, shedule_update, plan_beginning_month, machine, plan_month, fackt_month, variance FROM product_schedule WHERE id = ?;";


        try {
            $stmt = $this->db->prepare($query);
            $stmt->execute([$id]);
            $plans = $stmt->fetch(\PDO::FETCH_ASSOC);

            $jsonData = $plans['shedule_update'];
            $plan = json_decode($jsonData, true);

            // tte($plan);
            $jsonDataPlanBeginningMonth = $plans['plan_beginning_month'];
            $planBeginningMonth = json_decode($jsonDataPlanBeginningMonth, true);

            $total_plan_day_the_month = $planBeginningMonth['total_plan_day_the_month'];
            $total_plan_fact_the_month = $planBeginningMonth['total_plan_fact_the_month'];

            $plan_month = $plans['plan_month'];

            // общий месячный план
            $plan_month = [
                'plan_month' => $plan_month,
            ];


            $jsonDataMachine = $plans['machine'];
            $machine = json_decode($jsonDataMachine, true);
            $DataMachine = [
                'machine' => $machine,
            ];

            foreach ($plan as $item) {


                // Выводит данные только после второго пробела в строке
                $details = array_column($plan, 'detail');
                // $data = array_map(function ($detail) {
                //     $parts = explode(' ', $detail, 3);
                //     return isset ($parts[2]) ? $parts[2] : '';
                // }, $details);
                $uniqueDetails = array_unique($details);

                //  tte($data);
                // Выводит данные только после второго дефиса в дате (2024-01-01)
                $uniqueData = array_unique(array_map(function ($item) {
                    $parts = explode('-', $item['data'], 3);
                    return $parts[2]; // Возвращает данные после второго дефиса
                }, $plan));

                $uniquePlanMonthTn = array_unique(array_column($plan, 'plan_month_tn'));
                // $plan_month_tn = isset($item['plan_month_tn']) ? $item['plan_month_tn'] : '';
                $division_result_plan_day = isset ($item['division_result_plan_day']) ? $item['division_result_plan_day'] : '';
                $division_result_fact_day = isset ($item['division_result_fact_day']) ? $item['division_result_fact_day'] : '';
                $calc_difference = isset ($item['calc_difference']) ? $item['calc_difference'] : '';
                $stamping_workers_shift = isset ($item['stamping_workers_shift']) ? $item['stamping_workers_shift'] : '';

                $division_result_first_month = isset ($item['division_result_first_month']) ? $item['division_result_first_month'] : '';
                $division_result_second_month = isset ($item['division_result_second_month']) ? $item['division_result_second_month'] : '';


                $details = [
                    array_values($uniqueDetails),
                ];


                $plan_month_tn = [
                    array_values($uniquePlanMonthTn),
                ];
                $date = [
                    'date' => $uniqueData,
                ];


                $schedule[] = [

                    // Остальны данные из других ключей
                    // 'plan_month_tn' => $plan_month_tn,
                    'division_result_plan_day' => $division_result_plan_day,
                    'division_result_fact_day' => $division_result_fact_day,
                    'calc_difference' => $calc_difference,
                    'stamping_workers_shift' => $stamping_workers_shift,

                    'division_result_first_month' => $division_result_first_month,
                    'division_result_second_month' => $division_result_second_month,

                ];

            }


            // Модель с информацией о всем оборудовании 

            // $machine = $this->machineModel();

            // $foundItems = array();

            // foreach ($machine as $item) {
            //     foreach ($uniqueDetails as $key => $value) {
            //         if ($value === $item['productTitle']) {
            //             $foundItems[] = array(
            //                 'title' => $item['title'],
            //                 'numbers_part' => $item['numbers_part'],
            //                 'power' => $item['power']
            //             );
            //         }
            //     }
            // }

            // $result = array();
            // foreach ($foundItems as $item) {
            //     $resultMachine[] = $item;
            // }



            // tte($resultMachine);

            foreach ($total_plan_fact_the_month as $item) {

                $total_plan = [
                    'total_plan_fact_the_month' => $total_plan_fact_the_month,
                    'total_plan_day_the_month' => $total_plan_day_the_month,
                ];
            }


            // tte($total_plan);

            // выводит все данные с division_result_plan_day через запятую в виде строки
            $result = '';
            foreach ($schedule as $item) {
                if (isset ($item['division_result_plan_day'])) {
                    $result .= $item['division_result_plan_day'] . ', ';
                }
            }

            // выводит все данные с division_result_fact_day через запятую в виде строки
            $result_fact_day = '';
            foreach ($schedule as $item) {
                if (isset ($item['division_result_fact_day'])) {
                    $result_fact_day .= $item['division_result_fact_day'] . ', ';
                }
            }

            // выводит все данные с calc_difference через запятую в виде строки
            $result_calc_difference = '';
            foreach ($schedule as $item) {
                if (isset ($item['calc_difference'])) {
                    $result_calc_difference .= $item['calc_difference'] . ', ';
                }
            }

            // выводит все данные с stamping_workers_shift через запятую в виде строки
            $result_stamping_workers_shift = '';
            foreach ($schedule as $item) {
                if (isset ($item['stamping_workers_shift'])) {
                    $result_stamping_workers_shift .= $item['stamping_workers_shift'] . ', ';
                }
            }

            // выводит каждый элемент как элемент массива с division_result_plan_day
            $division_result_plan_day = explode(', ', rtrim($result, ', '));

            // выводит каждый элемент как элемент массива с division_result_fact_day
            $division_result_fact_day = explode(', ', rtrim($result_fact_day, ', '));

            // выводит каждый элемент как элемент массива с division_result_fact_day
            $calc_difference = explode(', ', rtrim($result_calc_difference, ', '));

            // выводит каждый элемент как элемент массива с stamping_workers_shift
            $stamping_workers_shift = explode(', ', rtrim($result_stamping_workers_shift, ', '));


            // tte($division_result_fact_day);
            $countDetail = count($uniqueDetails); // считаем количество title в массиве

            $count_division_result_plan_day = count($division_result_plan_day); // считаем количество division_result_plan_day в массиве

            $count_division_result_fact_day = count($division_result_fact_day); // считаем количество division_result_plan_day в массиве

            $count_calc_difference = count($calc_difference); // считаем количество calc_difference в массиве

            $count_stamping_workers_shift = count($stamping_workers_shift); // считаем количество stamping_workers_shift в массиве

            
            $chunks = array_chunk($division_result_plan_day, ceil($count_division_result_plan_day / $countDetail)); // делим количество тайтлов на дни плана и выводим каждую часть

            $division_result_fact_day = array_chunk($division_result_fact_day, ceil($count_division_result_fact_day / $countDetail));  // делим количество тайтлов на дни факта и выводим каждую часть

            $calc_difference = array_chunk($calc_difference, ceil($count_calc_difference / $countDetail));  // делим количество тайтлов на дни разницы и выводим каждую часть

            $stamping_workers_shift = array_chunk($stamping_workers_shift, ceil($count_stamping_workers_shift / $countDetail));  // делим количество тайтлов на кол-во штамповщиков и выводим каждую часть

            // Расчет выполнения плана за сутки по плану на все детали
            $sumTotalPlanMonth = array();
            foreach ($chunks as $array) {
                foreach ($array as $index => $value) {
                    if (!isset ($sumTotalPlanMonth[$index])) {
                        $sumTotalPlanMonth[$index] = 0;
                    }
                    $sumTotalPlanMonth[$index] += $value;
                }
            }
            // присваивается название массиву
            $sumTotalPlanMonth = [
                'sumTotalPlanMonth' => $sumTotalPlanMonth,
            ];

            $result = array();

            foreach ($chunks as $key => $chunk) {
                $result[$key] = array(
                    'title' => $details[0][$key],
                    'plan_month_tn' => $plan_month_tn[0][$key],
                    'division_result_plan_day' => array(),
                    'division_result_fact_day' => array(),
                    'calc_difference' => array(),
                    'stamping_workers_shift' => array()
                );
            
                foreach ($chunk as $value) {
                    $result[$key]['division_result_plan_day'][] = $value;
                }
            
                foreach ($division_result_fact_day[$key] as $value) {
                    $result[$key]['division_result_fact_day'][] = $value;
                }
            
                foreach ($calc_difference[$key] as $value) {
                    $result[$key]['calc_difference'][] = $value;
                }
            
                foreach ($stamping_workers_shift[$key] as $value) {
                    $result[$key]['stamping_workers_shift'][] = $value;
                }
            }

            return $result ? [$result, $date, $sumTotalPlanMonth, $total_plan, $plan_month, $DataMachine] : false;

        } catch (\PDOException $e) {
            return false;
        }

    }

    // Метод на создание записи в таблице графика месячного плана по id 
    public function createProductSchedule($plan_month_tn, $total_plan_month_tn, $detail)
    {


        $month = date('m'); // Получаем номер текущего месяца
        $year = date('Y'); // Получаем текущий год
        $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year); // Количество дней в текущем месяце

        $dates = ''; // Переменная для хранения всех дат

        for ($day = 1; $day <= $daysInMonth; $day++) {
            $date = date('Y-m-d', strtotime($year . '-' . $month . '-' . $day));
            $dates .= $date . "\n"; // Добавляем каждую дату в переменную с переносом строки
        }

        // tte($dates);
        $data_to_add = array();

        for ($i = 0; $i < count($detail); $i++) {
            $current_detail = $detail[$i];
            $current_plan_mont_tn = $plan_month_tn[$i];

            $division_result_plan_day = round($current_plan_mont_tn / $daysInMonth, 2); // расчет плана на один день
            $division_result_first_month = round(($daysInMonth / 2) * $division_result_plan_day, 2); // расчет плана на первую половину месяца
            $division_result_second_month = round(($daysInMonth / 2) * $division_result_plan_day, 2); // расчет плана на вторую половину месяца

            $division_result_fact_day = 0; // фактический результат за один день 
            $calc_difference = $division_result_plan_day - $division_result_fact_day; // разница 

            $machine = [
                'detail' => $current_detail,
                'plan_month_tn' => $current_plan_mont_tn,
            ];

            $division_result_plan_day_beggin_month = 0; // выполнение плана с начала месяца за день
            $division_result_fact_day_beggin_month = 0; // выполнение фактически с начала месяца за день

            $stamping_workers_shift = 0; // штамповщики в смену

            $data_to_add[$i] = array(
                'detail' => $current_detail, // название детали
                'plan_month_tn' => $current_plan_mont_tn,  // план на месяц в тоннах 
                'division_result_plan_day' => $division_result_plan_day, // расчет плана на один день
                'division_result_fact_day' => $division_result_fact_day, //фактически выполненный план за день

                'stamping_workers_shift' => $stamping_workers_shift, // штамповщики в смену

                'division_result_plan_day_beggin_month' => $division_result_plan_day_beggin_month, // выполнение плана с начала месяца  по плану
                'division_result_fact_day_beggin_month' => $division_result_fact_day_beggin_month, // выполнение плана с начала месяца  по факту

                'calc_difference' => $calc_difference, // разница между планом и фактом

                'machine' => $machine,

                'total_plan_day' => '',

                'division_result_first_month' => $division_result_first_month, // расчет плана на первую половину месяца
                'division_result_second_month' => $division_result_second_month, // расчет плана на вторую половину месяца
                'data' => '',
            );
        }


        $resultWithDates = array();

        $datesArray = explode("\n", $dates);

        foreach ($datesArray as $date) {
            // подставляет значение data в элемент массива
            foreach ($data_to_add as $item) {
                $item['data'] = $date;
                $resultWithDates[] = $item;
            }

        }
        // tte($resultWithDates);

        // сортирует массив по detail
        usort($resultWithDates, function ($a, $b) {
            return $a['detail'] <=> $b['detail'];
        });
        // подставляет значение data во все элементы массива, данные идут вместе с датой!!!
        $resultWithDates = array_filter($resultWithDates, function ($item) {
            return $item['data'] != '';
        });

        // tte($resultWithDates);
        // считаем количество уникальных деталей
        $details_values = [];

        foreach ($resultWithDates as $item) {
            $details_values[] = $item['detail'];
        }
        $unique_details_values = array_unique($details_values);
        $count_unique_details = count($unique_details_values); // считаем количество уникальных деталей

        // считаем количество планов дневных по плану
        $division_result_plan_day_values = [];

        foreach ($resultWithDates as $item) {
            $division_result_plan_day_values[] = $item['division_result_plan_day'];
        }

        $count_division_result_plan_day_values = count($division_result_plan_day_values);

        // считаем количество планов дневных
        $result = array_chunk($division_result_plan_day_values, ceil($count_division_result_plan_day_values / $count_unique_details));

        $arr = $result;
        $result = [];
        $previousValue = 0;

        for ($i = 0; $i < count($arr[0]); $i++) {
            $currentValue = $arr[0][$i] + $arr[1][$i];
            $result[$i] = $previousValue + $currentValue;
            $previousValue = $result[$i];
        }

        // считаем количество выполненного плана по факту 
        $division_result_fact_day_values = [];

        foreach ($resultWithDates as $item) {
            $division_result_fact_day_values[] = $item['division_result_fact_day'];
        }

        $count_division_result_fact_day_values = count($division_result_fact_day_values);

        // считаем количество планов дневных
        $result2 = array_chunk($division_result_fact_day_values, ceil($count_division_result_fact_day_values / $count_unique_details));

        $arr = $result2;
        $result2 = [];
        $previousValue2 = 0;

        for ($i = 0; $i < count($arr[0]); $i++) {
            $currentValue2 = $arr[0][$i] + $arr[1][$i];
            $result2[$i] = $previousValue2 + $currentValue2;
            $previousValue2 = $result2[$i];
        }

        $total_plan_fact_day_the_month = array(
            'total_plan_day_the_month' => $result,
            'total_plan_fact_the_month' => $result2,
        );

        $resultWithKeys = array_values($resultWithDates); // Переиндексация массива

        //   tte($total_plan_fact_day_the_month);

        //  tte($resultWithKeys);
        $json_data = json_encode($resultWithKeys, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);


        $json_data_total_plan_fact_day_the_month = json_encode($total_plan_fact_day_the_month, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);

        $query = "INSERT INTO product_schedule (date, whom, provided_whom, schedule, plan_beginning_month, plan_month) VALUES (:date, :whom, :provided_whom, :schedule, :plan_beginning_month, :plan_month)";

        try {
            $stmt = $this->db->prepare($query);

            $stmt->bindParam(":date", $_POST["date"]);
            $stmt->bindParam(":whom", $_POST["agreed"]);
            $stmt->bindParam(":provided_whom", $_POST["ratify"]);
            $stmt->bindParam(":schedule", $json_data);
            $stmt->bindParam(":plan_beginning_month", $json_data_total_plan_fact_day_the_month);
            $stmt->bindParam(":plan_month", $_POST["total_plan_month_tn"]);

            $stmt->execute();

            echo "Данные успешно сохранены!";

        } catch (\PDOException $e) {
            echo "Ошибка при сохранении данных: " . $e->getMessage();
        }


    }

    // пока не нужно, основное находится в MonitoringUpdateModel
    public function updateShedule($id, $plan_month_tn, $total_plan_month_tn, $detail)
    {


        $month = date('m'); // Получаем номер текущего месяца
        $year = date('Y'); // Получаем текущий год
        $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year); // Количество дней в текущем месяце

        $dates = ''; // Переменная для хранения всех дат

        for ($day = 1; $day <= $daysInMonth; $day++) {
            $date = date('Y-m-d', strtotime($year . '-' . $month . '-' . $day));
            $dates .= $date . "\n"; // Добавляем каждую дату в переменную с переносом строки
        }

        $data_to_add = array();

        for ($i = 0; $i < count($detail); $i++) {
            $current_detail = $detail[$i];
            $current_plan_mont_tn = $plan_month_tn[$i];

            $division_result_plan_day = round($current_plan_mont_tn / $daysInMonth, 2); // расчет плана на один день
            $division_result_first_month = round(($daysInMonth / 2) * $division_result_plan_day, 2); // расчет плана на первую половину месяца
            $division_result_second_month = round(($daysInMonth / 2) * $division_result_plan_day, 2); // расчет плана на вторую половину месяца

            $division_result_fact_day = 0; // фактический результат за один день 
            $calc_difference = $division_result_plan_day - $division_result_fact_day; // разница 



            $division_result_plan_day_beggin_month = 0; // выполнение плана с начала месяца за день
            $division_result_fact_day_beggin_month = 0; // выполнение фактически с начала месяца за день

            $stamping_workers_shift = 0; // штамповщики в смену

            $data_to_add[$i] = array(
                'detail' => $current_detail, // название детали
                'plan_month_tn' => $current_plan_mont_tn,  // план на месяц в тоннах 
                'division_result_plan_day' => $division_result_plan_day, // расчет плана на один день
                'division_result_fact_day' => $division_result_fact_day, //фактически выполненный план за день

                'stamping_workers_shift' => $stamping_workers_shift, // штамповщики в смену

                'division_result_plan_day_beggin_month' => $division_result_plan_day_beggin_month, // выполнение плана с начала месяца  по плану
                'division_result_fact_day_beggin_month' => $division_result_fact_day_beggin_month, // выполнение плана с начала месяца  по факту

                'calc_difference' => $calc_difference, // разница между планом и фактом

                'total_plan_day' => '',

                'division_result_first_month' => $division_result_first_month, // расчет плана на первую половину месяца
                'division_result_second_month' => $division_result_second_month, // расчет плана на вторую половину месяца
                'data' => '',
            );

        }



        $resultWithDates = array();

        $datesArray = explode("\n", $dates);

        foreach ($datesArray as $date) {
            // подставляет значение data в элемент массива
            foreach ($data_to_add as $item) {
                $item['data'] = $date;
                $resultWithDates[] = $item;
            }

        }

        // сортирует массив по detail
        usort($resultWithDates, function ($a, $b) {
            return $a['detail'] <=> $b['detail'];
        });
        // подставляет значение data во все элементы массива
        $resultWithDates = array_filter($resultWithDates, function ($item) {
            return $item['data'] != '';
        });


        // считаем количество уникальных деталей
        $details_values = [];

        foreach ($resultWithDates as $item) {
            $details_values[] = $item['detail'];
        }
        $unique_details_values = array_unique($details_values);
        $count_unique_details = count($unique_details_values); // считаем количество уникальных деталей

        // считаем количество планов дневных по плану
        $division_result_plan_day_values = [];

        foreach ($resultWithDates as $item) {
            $division_result_plan_day_values[] = $item['division_result_plan_day'];
        }

        $count_division_result_plan_day_values = count($division_result_plan_day_values);

        // считаем количество планов дневных
        $result = array_chunk($division_result_plan_day_values, ceil($count_division_result_plan_day_values / $count_unique_details));



        // считаем количество выполненного плана по факту 
        $division_result_fact_day_values = [];

        foreach ($resultWithDates as $item) {
            $division_result_fact_day_values[] = $item['division_result_fact_day'];
        }

        $count_division_result_fact_day_values = count($division_result_fact_day_values);

        // считаем количество планов дневных
        $result2 = array_chunk($division_result_fact_day_values, ceil($count_division_result_fact_day_values / $count_unique_details));

        $total_plan_fact_day_the_month = array(
            'total_plan_day_the_month' => $result,
            'total_plan_fact_the_month' => $result2,
        );

        $resultWithKeys = array_values($resultWithDates); // Переиндексация массива

        //   tte($total_plan_fact_day_the_month);

        //  tte($resultWithKeys);
        $json_data = json_encode($resultWithKeys, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);


        $json_data_total_plan_fact_day_the_month = json_encode($total_plan_fact_day_the_month, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);

        $query = "UPDATE product_schedule SET date = :date, whom = :whom, provided_whom = :provided_whom, schedule = :schedule, plan_beginning_month = :plan_beginning_month, plan_month = :plan_month WHERE id = :id";

        try {
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":date", $_POST["date"]);
            $stmt->bindParam(":whom", $_POST["agreed"]);
            $stmt->bindParam(":provided_whom", $_POST["ratify"]);
            $stmt->bindParam(":schedule", $json_data);
            $stmt->bindParam(":plan_beginning_month", $json_data_total_plan_fact_day_the_month);
            $stmt->bindParam(":plan_month", $_POST["total_plan_month_tn"]);
            $stmt->bindParam(":id", $id);


            $stmt->execute();

            return true; // Возвращаем true, если запрос выполнен успешно
        } catch (\PDOException $e) {
            // Обработка ошибок, например, запись в журнал или вывод сообщения об ошибке
            error_log("Ошибка при обновлении плана: " . $e->getMessage());
            return false;
        }
    }



}