<?php
namespace models\product\product_schedule;

use models\Database;
use models\product\product_schedule\ProductScheduleModel;

class MonitoringUpdateModel
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    public function getAllData()
    {

        $address = '192.168.1.2';
        $port = 50880;

        try {

            //echo 'Создание сокета ... ';         
            $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
            if ($socket < 0) {
                throw new \Exception('socket_create() failed: ' . socket_strerror(socket_last_error()) . "\n");
            } else {
                //echo "выполнено.\n";         
            }


            //echo 'Соединение с сокетом ... ';         
            $result = socket_connect($socket, $address, $port);
            if ($result === false) {
                throw new \Exception('socket_connect() failed: ' . socket_strerror(socket_last_error()) . "\n");
            } else {
                //echo "установлено.\n";         
            }

            //echo 'Отправка данных: ';      
            $byteOut = socket_send($socket, chr(15), 1, 0);
            if ($byteOut === false) {
                //  echo " Ошибка.";           
                throw new \Exception('socket_send() failed: ' . socket_strerror(socket_last_error()) . "\n");
            } else {
                //    echo "отправлено ".$byteOut." байт.\n";         
            }

            $byte = socket_recv($socket, $in, 898, 0);
            if ($byte === false) {
                // echo " Ошибка.";           
                throw new \Exception('socket_recv() failed: ' . socket_strerror(socket_last_error()) . "\n");
            } else {
                //Преобразуем строку ASCII в массив UInt16 ("S*" - беззнаковый 16 bit, машинный байтовый порядок), массив начинается с 1 (а не 0)
                $id1 = unpack("S*", substr($in, 0, 34));
                $id42 = unpack("S*", substr($in, 226, 2));
                $id45 = unpack("S*", substr($in, 244, 2));
                $id48 = unpack("S*", substr($in, 262, 2));
                $id51 = unpack("S*", substr($in, 280, 6));
                $id57 = unpack("S*", substr($in, 310, 8));
                $id65 = unpack("S*", substr($in, 350, 8));
                $id74 = unpack("S*", substr($in, 398, 10));
                $id89 = unpack("S*", substr($in, 488, 4));  //Дискретные входа  
                $id188 = unpack("S*", substr($in, 862, 2));  //Дискретные входа на линии накатки


                //Отрабковка на пресс
                $B12b = unpack("s*", substr($in, 10, 2)); //Пресс №4
                $B11b = unpack("s*", substr($in, 4, 2)); //Пресс №5
                $B13b = unpack("s*", substr($in, 16, 2)); //Пресс №3
                $B14b = unpack("s*", substr($in, 22, 2)); //Пресс №2 
                $B14b_1 = unpack("s*", substr($in, 284, 2)); //Пресс №1
                $B16b = unpack("s*", substr($in, 352, 2)); //Пресс №6

                //Преобразуем строку ASCII в массив Int64 ("q*" - знаковый 64 bit, машинный байтовый порядок)
                $id18 = unpack("q*", substr($in, 34, 192));
                $id43 = unpack("q*", substr($in, 228, 16));
                $id46 = unpack("q*", substr($in, 246, 16));
                $id49 = unpack("q*", substr($in, 264, 16));
                $id54 = unpack("q*", substr($in, 286, 24));
                $id61 = unpack("q*", substr($in, 318, 32));
                $id69 = unpack("q*", substr($in, 358, 40));
                $id79 = unpack("q*", substr($in, 408, 80));

                //Цикл линии прокатки в секундах
                $id189 = unpack("s*", substr($in, 864, 34));

                //КТП 630
                $id92 = unpack("f*", substr($in, 496, 168));
                //КТП 1000
                $id137 = unpack("f*", substr($in, 674, 168));

                //Цикл линии прокатки дискретный вход на цвета
                $inWater1 = substr(sprintf('%016b', $id188[1]), -1, 1); //Линия №1
                $inWater2 = substr(sprintf('%016b', $id188[1]), -2, 1); //Линия №2
                $inWater3 = substr(sprintf('%016b', $id188[1]), -3, 1); //Линия №3
                $inWater4 = substr(sprintf('%016b', $id188[1]), -4, 1); //Линия №4
                $inWater5 = substr(sprintf('%016b', $id188[1]), -5, 1); //Линия №5

                //Форматируем дату, время и интервалы.

                $Ns_DateTiks = $id18[1] ^ ($id18[1] & -4611686018427387904); //Дата и время начала смены (.Net)
                $Ns = date("d.m.Y H:i:s", intval($Ns_DateTiks / 10000000 - 62135596800)); //Дата и время начала смены (Unix с форматированием)

                $TimS_DateTiks = $id18[2] ^ ($id18[2] & -4611686018427387904); //Текущее время сервера (.Net)
                $TimS = date("H:i:s", intval($TimS_DateTiks / 10000000 - 62135596800)); //Текущее время сервера (Unix с форматированием)

                $Tim_UnixTiks = intval($TimS_DateTiks / 10000000 - 62135596800) - intval($Ns_DateTiks / 10000000 - 62135596800); //Время прошедшее с начала смемы (Unix)
                $Tim_s = gmdate("H:i:s", $Tim_UnixTiks); //Время прошедшее с начала смемы (Unix с форматированием)
                $Tim_ms = fmod((intval($TimS_DateTiks / 1000000 - 621355968000) - intval($Ns_DateTiks / 1000000 - 621355968000)), 10); //Дробный остаток от деления (милисек.)
                $Tim = $Tim_s . sprintf('.%01d', $Tim_ms); //Продолжительность смены с милисекундами.


                //Пресс №5
                $N1 = gmdate("H:i:s", intval($id18[3] / 10000000)); //Время цикла
                $Q1 = gmdate("H:i:s", intval($id18[4] / 10000000)); //Простой
                $N1hc = intval($id18[5] / 1000000) / 10; //Среднее время цикла нагрева

                //Пресс №4
                $N2 = gmdate("H:i:s", intval($id18[6] / 10000000)); //Время цикла
                $Q2 = gmdate("H:i:s", intval($id18[7] / 10000000)); //Простой
                $N2hc = intval($id18[8] / 1000000) / 10; //Среднее время цикла нагрева

                //Пресс №3
                $N3 = gmdate("H:i:s", intval($id18[9] / 10000000)); //Время цикла
                $Q3 = gmdate("H:i:s", intval($id18[10] / 10000000)); //Простой
                $N3hc = intval($id18[11] / 1000000) / 10; //Среднее время цикла нагрева

                //Пресс №2
                $N4 = gmdate("H:i:s", intval($id18[12] / 10000000)); //Время цикла
                $Q4 = gmdate("H:i:s", intval($id18[13] / 10000000)); //Простой
                $N4hc = intval($id18[14] / 1000000) / 10; //Среднее время цикла нагрева

                //Накатка №4
                $N5 = gmdate("H:i:s", intval($id18[15] / 10000000)); //Время цикла
                $Q5 = gmdate("H:i:s", intval($id18[16] / 10000000)); //Простой

                //Накатка №5
                $N6 = gmdate("H:i:s", intval($id18[17] / 10000000)); //Время цикла
                $Q6 = gmdate("H:i:s", intval($id18[18] / 10000000)); //Простой

                //Накатка №2
                $N7 = gmdate("H:i:s", intval($id18[19] / 10000000)); //Время цикла
                $Q7 = gmdate("H:i:s", intval($id18[20] / 10000000)); //Простой

                //Накатка №1
                $N8 = gmdate("H:i:s", intval($id18[21] / 10000000)); //Время цикла
                $Q8 = gmdate("H:i:s", intval($id18[22] / 10000000)); //Простой

                //Пресс Р2
                $N9 = gmdate("H:i:s", intval($id18[23] / 10000000)); //Время цикла
                $Q9 = gmdate("H:i:s", intval($id18[24] / 10000000)); //Простой

                //Пресс Р1
                $N10 = gmdate("H:i:s", intval($id43[1] / 10000000)); //Время цикла
                $Q10 = gmdate("H:i:s", intval($id43[2] / 10000000)); //Простой

                //Калибровочный стан
                $N10_1 = gmdate("H:i:s", intval($id46[1] / 10000000)); //Время цикла
                $Q10_1 = gmdate("H:i:s", intval($id46[2] / 10000000)); //Простой

                //Накатка №3
                $N8_1 = gmdate("H:i:s", intval($id49[1] / 10000000)); //Время цикла
                $Q8_1 = gmdate("H:i:s", intval($id49[2] / 10000000)); //Простой

                //Пресс №1
                $N4_1 = gmdate("H:i:s", intval($id54[1] / 10000000)); //Время цикла
                $Q4_1 = gmdate("H:i:s", intval($id54[2] / 10000000)); //Простой
                $N4hc_1 = intval($id54[3] / 1000000) / 10; //Среднее время цикла нагрева

                //Пресс №6
                $N22 = gmdate("H:i:s", intval($id61[1] / 10000000)); //Время цикла
                $Q21 = gmdate("H:i:s", intval($id61[2] / 10000000)); //Простой
                $N6hc = intval($id69[1] / 1000000) / 10; //Среднее время цикла нагрева

                //Костыльный аппарат №2
                $N24 = gmdate("H:i:s", intval($id61[3] / 10000000)); //Время цикла
                $Q22 = gmdate("H:i:s", intval($id61[4] / 10000000)); //Простой

                //Пресс гидравлический
                $N26 = gmdate("H:i:s", intval($id69[2] / 10000000)); //Время цикла
                $Q23 = gmdate("H:i:s", intval($id69[3] / 10000000)); //Простой

                //Костыльный аппарат №1
                $N28 = gmdate("H:i:s", intval($id69[4] / 10000000)); //Время цикла
                $Q25 = gmdate("H:i:s", intval($id69[5] / 10000000)); //Простой

                //Пресс №9
                $Ntc7_2 = gmdate("H:i:s", intval($id79[1] / 10000000)); //Время цикла
                $Ntps7_2 = gmdate("H:i:s", intval($id79[2] / 10000000)); //Простой  

                //Резьбонакатной станок №1
                $Ntc8_2 = gmdate("H:i:s", intval($id79[3] / 10000000)); //Время цикла
                $Ntps8_2 = gmdate("H:i:s", intval($id79[4] / 10000000)); //Простой

                //Резьбонакатной станок №2
                $Ntc9_2 = gmdate("H:i:s", intval($id79[5] / 10000000)); //Время цикла
                $Ntps9_2 = gmdate("H:i:s", intval($id79[6] / 10000000)); //Простой

                //Гайканарезной станок №1
                $Ntc10_2 = gmdate("H:i:s", intval($id79[7] / 10000000)); //Время цикла
                $Ntps10_2 = gmdate("H:i:s", intval($id79[8] / 10000000)); //Простой

                //Пресс №10
                $Ntc11_2 = gmdate("H:i:s", intval($id79[9] / 10000000)); //Время цикла
                $Ntps11_2 = gmdate("H:i:s", intval($id79[10] / 10000000)); //Простой 

                //  Простои в процентах
                $Q3p = round(100 * intval($id18[10] / 10000000) / $Tim_UnixTiks); //Пресс №3 
                $Q4p = round(100 * intval($id18[13] / 10000000) / $Tim_UnixTiks); //Пресс №2 
                $Q5p = round(100 * intval($id18[16] / 10000000) / $Tim_UnixTiks); //Накатка №4
                $Q6p = round(100 * intval($id18[18] / 10000000) / $Tim_UnixTiks); //Накатка №5
                $Q7p = round(100 * intval($id18[20] / 10000000) / $Tim_UnixTiks); //Накатка №2
                $Q8p = round(100 * intval($id18[22] / 10000000) / $Tim_UnixTiks); //Накатка №1
                $Q1p = round(100 * intval($id18[4] / 10000000) / $Tim_UnixTiks); //Пресс №5
                $Q2p = round(100 * intval($id18[7] / 10000000) / $Tim_UnixTiks); //Пресс №4
                $Q9p = round(100 * intval($id18[24] / 10000000) / $Tim_UnixTiks); //Пресс Р2
                $Q10p = round(100 * intval($id43[2] / 10000000) / $Tim_UnixTiks); //Пресс Р1
                $Q10_1p = round(100 * intval($id46[2] / 10000000) / $Tim_UnixTiks); //Калибровочный стан
                $Q8_1p = round(100 * intval($id49[2] / 10000000) / $Tim_UnixTiks); //Накатка №3
                $Q4_1p = round(100 * intval($id54[2] / 10000000) / $Tim_UnixTiks); //Пресс №1
                $Q21p = round(100 * intval($id61[2] / 10000000) / $Tim_UnixTiks); //Пресс №6
                $Q22p = round(100 * intval($id61[4] / 10000000) / $Tim_UnixTiks); //Костыльный аппарат №2
                $Q23p = round(100 * intval($id69[3] / 10000000) / $Tim_UnixTiks); //Пресс гидравлический
                $Q25p = round(100 * intval($id69[5] / 10000000) / $Tim_UnixTiks); //Костыльный аппарат №1
                $Ntps7_2p = round(100 * intval($id79[2] / 10000000) / $Tim_UnixTiks); //Пресс №9
                $Ntps8_2p = round(100 * intval($id79[4] / 10000000) / $Tim_UnixTiks); //Резьбонакатной станок №1
                $Ntps9_2p = round(100 * intval($id79[6] / 10000000) / $Tim_UnixTiks); //Резьбонакатной станок №2
                $Ntps10_2p = round(100 * intval($id79[8] / 10000000) / $Tim_UnixTiks); //Гайканарезной станок №1
                $Ntps11_2p = round(100 * intval($id79[10] / 10000000) / $Tim_UnixTiks); //Пресс №10

                //Дискретные входа
                $in1V0 = substr(sprintf('%016b', $id89[1]), -1, 1); //Пресс №5
                $in1V1 = substr(sprintf('%016b', $id89[1]), -2, 1); //Пресс №4
                $in1V2 = substr(sprintf('%016b', $id89[1]), -3, 1); //Пресс №3
                $in1V3 = substr(sprintf('%016b', $id89[1]), -4, 1); //Пресс №2
                $in1V4 = substr(sprintf('%06b', $id89[1]), -6, 1); //Накатка №5
                $in1V6 = substr(sprintf('%016b', $id89[1]), -5, 1); //Накатка №4
                $in1V5 = substr(sprintf('%016b', $id89[1]), -7, 1); //Накатка №2
                $in1V7 = substr(sprintf('%016b', $id89[1]), -8, 1); //Накатка №1
                $in1V8 = substr(sprintf('%016b', $id89[1]), -9, 1); //Нагрев пресса №5
                $in1V9 = substr(sprintf('%016b', $id89[1]), -10, 1); //Нагрев пресса №4
                $in1V10 = substr(sprintf('%016b', $id89[1]), -11, 1); //Нагрев пресса №3
                $in1V11 = substr(sprintf('%016b', $id89[1]), -12, 1); //Нагрев пресса №2
                $in1V12 = substr(sprintf('%016b', $id89[1]), -13, 1); //Накатка №3
                $in1V13 = substr(sprintf('%016b', $id89[1]), -14, 1); //Пресс Р1
                $in1V14 = substr(sprintf('%016b', $id89[1]), -15, 1); //Калибровочный стан
                $in1V15 = substr(sprintf('%016b', $id89[1]), -16, 1); //Пресс Р2

                $in2V0 = substr(sprintf('%016b', $id89[2]), -1, 1); //Пресс №1
                $in2V1 = substr(sprintf('%016b', $id89[2]), -2, 1); //Нагрев пресса №1
                $in2V2 = substr(sprintf('%016b', $id89[2]), -3, 1); //Пресс №6
                $in2V3 = substr(sprintf('%016b', $id89[2]), -4, 1); //Нагрев пресса №6
                $in2V4 = substr(sprintf('%016b', $id89[2]), -5, 1); //Костыльный аппарат №1
                $in2V5 = substr(sprintf('%016b', $id89[2]), -6, 1); //Костыльный аппарат №2
                $in2V6 = substr(sprintf('%016b', $id89[2]), -7, 1); //Пресс гидравлический
                $in2V7 = substr(sprintf('%016b', $id89[2]), -8, 1); //Пресс №9
                $in2V8 = substr(sprintf('%016b', $id89[2]), -9, 1); //Резьбонакатной станок №1
                $in2V9 = substr(sprintf('%016b', $id89[2]), -10, 1); //Резьбонакатной станок №2
                $in2V10 = substr(sprintf('%016b', $id89[2]), -11, 1); //Гайканарезной станок №1
                $in2V11 = substr(sprintf('%016b', $id89[2]), -12, 1); //Пресс №10
                $in2V12 = substr(sprintf('%016b', $id89[2]), -13, 1); //Резерв
                $in2V13 = substr(sprintf('%016b', $id89[2]), -14, 1); //Резерв
                $in2V14 = substr(sprintf('%016b', $id89[2]), -15, 1); //Резерв
                $in2V15 = substr(sprintf('%016b', $id89[2]), -16, 1); //Резерв


            }
        } catch (\Exception $e) {
            //echo "\nError: ".$e->getMessage();     
        }
        if (isset($socket)) {
            //echo 'Close socket ... ';         
            socket_close($socket);
            //echo "OK\n";             
        }


        $summKalibrovka = $id42[1] + $id1[17];
        $summCostlApparat = $id65[4] + $id57[4];
        $summLineProckat = $id1[16] + $id1[15] + $id48[1] + $id1[13] + $id1[14];
        $weight = round($summLineProckat * 712 / 1000);
        $crutch_device = round(($id65[4] + $id57[4]) * 362 / 1000);


        $result = [
            "Ns" => $Ns,
            "TimS" => $TimS,
            "Tim" => $Tim_s,

            // Калибровочный стан
            "idKS_1_calibration_mill" => $id45[1], // кол-во деталей

            "idKS_4" => $Q10_1, //простой
            "idKS_5" => $N10_1, // время цикла
            "idKS_7" => $Q10_1p, // простой %

            // пресс P1
            "idP1_1_press_P1" => $id42[1], // кол-во деталей

            "idP1_4" => $Q10, //простой 
            "idP1_5" => $N10, // время цикла
            "idP1_7" => $Q10p, // простой %

            // пресс P2
            "idP2_1_press_P2" => $id1[17], // кол-во деталей

            "idP2_4" => $Q9, //простой 
            "idP2_5" => $N9, // время цикла
            "idP2_7" => $Q9p, // простой %

            // пресс 5
            "id5_1_press_5" => $id1[1], // кол-во деталей
            "id5_2" => $id1[2], // кол-во нагретых заготовок
            "id5_3" => $B11b[1], //кол-во отбракованных заготовок

            "id5_4" => $Q1, //простой 
            "id5_5" => $N1, // время цикла
            "id5_6" => $N1hc, // среднее время цикла нагрева
            "id5_7" => $Q1p, // простой %


            // пресс 4
            "id4_1_press_4" => $id1[4], // кол-во деталей
            "id4_2" => $id1[5], // кол-во нагретых заготовок
            "id4_3" => $B12b[1], //кол-во отбракованных заготовок

            "id4_4" => $Q2, //простой
            "id4_5" => $N2, // время цикла
            "id4_6" => $N2hc, // среднее время цикла нагрева
            "id4_7" => $Q2p, // простой %

            // пресс 3
            "id3_1_press_3" => $id1[7], // кол-во деталей
            "id3_2" => $id1[8], // кол-во нагретых заготовок
            "id3_3" => $B13b[1], //кол-во отбракованных заготовок

            "id3_4" => $Q3, //простой 
            "id3_5" => $N3, // время цикла
            "id3_6" => $N3hc, // среднее время цикла нагрева
            "id3_7" => $Q3p, // простой %


            // пресс 2
            "id2_1_press_2" => $id1[10], // кол-во деталей
            "id2_2" => $id1[11], // кол-во нагретых заготовок
            "id2_3" => $B14b[1], //кол-во отбракованных заготовок

            "id2_4" => $Q4, //простой 
            "id2_5" => $N4, // время цикла
            "id2_6" => $N4hc, // среднее время цикла нагрева
            "id2_7" => $Q4p, // простой %


            // пресс 1
            "id1_1_press_1" => $id51[1], // кол-во деталей
            "id1_2" => $id51[2], // кол-во нагретых заготовок
            "id1_3" => $B14b_1[1], //кол-во отбракованных заготовок

            "id1_4" => $Q4_1, //простой 
            "id1_5" => $N4_1, // время цикла
            "id1_6" => $N4hc_1, // среднее время цикла нагрева
            "id1_7" => $Q4_1p, // простой %


            // пресс 6
            "id6_1_press_6" => $id57[1], // кол-во деталей
            "id6_2" => $id65[1], // кол-во нагретых заготовок
            "id6_3" => $B16b[1], //кол-во отбракованных заготовок

            "id6_4" => $Q21, //простой 
            "id6_5" => $N22, // время цикла
            "id6_6" => $N6hc, // среднее время цикла нагрева
            "id6_7" => $Q21p, // простой %

            // пресс 10
            "id10_1_press_10" => $id74[5], // кол-во деталей

            "id10_4" => $Ntps11_2, //простой  
            "id10_5" => $Ntc11_2, // время цикла
            "id10_7" => $Ntps11_2p, // простой %


            // Линии попперечно-клиновой прокатки

            // Линия №1
            "idL1_1_line_1" => $id1[16], // кол-во деталей

            "idL1_4" => $Q8, //простой 
            "idL1_5" => $N8, // время цикла
            "idL1_7" => $Q8p, // простой %

            "idL1_8" => $id189[13] / 10, //цикл накатки, выводится целое число, нужно перевести в секунды, поэтому делим на 10

            "idL1_9" => $inWater1, // подстветка линии при ее работе
            // Линия №2
            "idL2_1_line_2" => $id1[15], // кол-во деталей

            "idL2_4" => $Q7, //простой 
            "idL2_5" => $N7, // время цикла
            "idL2_7" => $Q7p, // простой %

            "idL2_8" => $id189[14] / 10, //цикл накатки

            "idL2_9" => $inWater2, // подстветка линии при ее работе

            // Линия №3
            "idL3_1_line_3" => $id48[1], // кол-во деталей

            "idL3_4" => $Q8_1, //простой 
            "idL3_5" => $N8_1, // время цикла
            "idL3_7" => $Q8_1p, // простой %

            "idL3_8" => $id189[15] / 10, //цикл накатки

            "idL3_9" => $inWater3, // подстветка линии при ее работе

            // Линия №4
            "idL4_1_line_4" => $id1[13], // кол-во деталей

            "idL4_4" => $Q5, //простой 
            "idL4_5" => $N5, // время цикла
            "idL4_7" => $Q5p, // простой %

            "idL4_8" => $id189[16] / 10, //цикл накатки

            "idL4_9" => $inWater4, // подстветка линии при ее работе

            // Линия №5
            "idL5_1_line_5" => $id1[14], // кол-во деталей

            "idL5_4" => $Q6, //простой 
            "idL5_5" => $N6, // время цикла
            "idL5_7" => $Q6p, // простой %

            "idL5_8" => $id189[17] / 10, //цикл накатки

            "idL5_9" => $inWater5, // подстветка линии при ее работе

            //Костыльные аппараты

            //Костыльный аппарат №1
            "idK1_1_crutch_1" => $id65[4], // кол-во деталей

            "idK1_4" => $Q25, //простой 
            "idK1_5" => $N28, // время цикла
            "idK1_7" => $Q25p, // простой %

            //Костыльный аппарат №2
            "idK2_1_crutch_2" => $id57[4], // кол-во деталей

            "idK2_4" => $Q22, //простой 
            "idK2_5" => $N24, // время цикла
            "idK2_7" => $Q22p, // простой %


            //Пресс гидравлический

            //Пресс гидравлический №1
            "idPG1_1_hydraulic_press_1" => $id65[3], // кол-во деталей

            "idPG1_4" => $Q23, //простой 
            "idPG1_5" => $N26, // время цикла
            "idPG1_7" => $Q23p, // простой %


            //Резьбонакатной станок

            //Станок №1
            "idR1_1_threaded_1" => $id74[2], // кол-во деталей

            "idR1_4" => $Ntps8_2, //простой 
            "idR1_5" => $Ntc8_2, // время цикла
            "idR1_7" => $Ntps8_2p, // простой %

            //Станок №2
            "idR2_1_threaded_1" => $id74[3], // кол-во деталей

            "idR2_4" => $Ntps9_2, //простой 
            "idR2_5" => $Ntc9_2, // время цикла
            "idR2_7" => $Ntps9_2p, // простой %


            //Гайконарезной станок

            //Станок №1
            "idG1_1_cutting_1" => $id74[4], // кол-во деталей

            "idG1_4" => $Ntps10_2, //простой 
            "idG1_5" => $Ntc10_2, // время цикла
            "idG1_7" => $Ntps10_2p, // простой %


            //Пресс 9

            //Пресс №9
            "idP9_1_press_9" => $id74[1], // кол-во деталей

            "idP9_4" => $Ntps7_2, //простой 
            "idP9_5" => $Ntc7_2, // время цикла
            "idP9_7" => $Ntps7_2p, // простой %

            //Количество, вес заготовок на оборудовании
            "summKalibrovka" => $summKalibrovka,
            "summLineProckat" => $summLineProckat,
            "summCostlApparat" => $summCostlApparat,
            "weight" => $weight,
            "crutch_device" => $crutch_device,


            //Дискретные входа
            "in1V0" => $in1V0, //Пресс №5
            "in1V1" => $in1V1, //Пресс №4
            "in1V2" => $in1V2, //Пресс №3
            "in1V3" => $in1V3, //Пресс №2
            "in1V4" => $in1V4, //Накатка №5
            "in1V5" => $in1V5, //Накатка №2
            "in1V6" => $in1V6, //Накатка №4
            "in1V7" => $in1V7, //Накатка №1
            "in1V8" => $in1V8, //Нагрев пресса №5
            "in1V9" => $in1V9, //Нагрев пресса №4
            "in1V10" => $in1V10, //Нагрев пресса №3
            "in1V11" => $in1V11, //Нагрев пресса №2
            "in1V12" => $in1V12, //Накатка №3
            "in1V13" => $in1V13, //Пресс Р1
            "in1V14" => $in1V14, //Калибровочный стан
            "in1V15" => $in1V15, //Пресс Р2

            "in2V0" => $in2V0, //Пресс №1
            "in2V1" => $in2V1, //Нагрев пресса №1
            "in2V2" => $in2V2, //Пресс №6
            "in2V3" => $in2V3, //Нагрев пресса №6
            "in2V4" => $in2V4, //Костыльный аппарат №1
            "in2V5" => $in2V5, //Костыльный аппарат №2
            "in2V6" => $in2V6, //Пресс гидравлический
            "in2V7" => $in2V7, //Пресс №9
            "in2V8" => $in2V8, //Резьбонакатной станок №1
            "in2V9" => $in2V9, //Резьбонакатной станок №2
            "in2V10" => $in2V10, //Гайканарезной станок №1
            "in2V11" => $in2V11, //Пресс №10
            "in2V12" => $in2V12, //Резерв
            "in2V13" => $in2V13, //Резерв
            "in2V14" => $in2V14, //Резерв
            "in2V15" => $in2V15, //Резерв

            // Подстанция ТП-1 630 кВА
            "tp1_1" => round($id92[16] * 10 / 63), // максимальная нагрузка трансформатора
            "tp1_2" => round(($id92[13] + $id92[14] + $id92[15]) * 10 / 63), // нагрузка трансформатора

            "tp1_3" => round($id92[42]), // Накопленная мощность
            // Подстанция ТП-2 1000 кВА
            "tp2_1" => round($id137[16] / 10), // максимальная нагрузка трансформатора
            "tp2_2" => round(($id137[13] + $id137[14] + $id137[15]) / 10), // нагрузка трансформатора

            "tp2_3" => round($id137[42]), // Накопленная мощность

            "tp_sum" => round($id92[42] + $id137[42]), // Сумма всего расхода

            "temp_air" => $id189[12],
            "temp_tank" => $id189[11],

            // "tp1_1" => 80,
            // "tp1_2" =>  100,
            // "tp2_1" => 100 ,
            // "tp2_2" => 100,
        ];

        return $result;

    }

    public function updateShedule($id, $plan_month_tn, $total_plan_month_tn, $detail)
    {

        $data = $this->getAllData();

        $resultTest = $data['idP1_1_press_P1'];
        
        $month = date('m'); // Получаем номер текущего месяца
        $year = date('Y'); // Получаем текущий год
        $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year); // Количество дней в текущем месяце

        $dates = ''; // Переменная для хранения всех дат

        for ($day = 1; $day <= $daysInMonth; $day++) {
            $date = date('Y-m-d', strtotime($year . '-' . $month . '-' . $day));
            $dates .= $date . "\n"; // Добавляем каждую дату в переменную с переносом строки
        }

        $data_to_add = array();

        for ($i = 0; $i < count($detail); $i++) {
            $current_detail = $detail[$i];
            $current_plan_mont_tn = $plan_month_tn[$i];

            $division_result_plan_day = round($current_plan_mont_tn / $daysInMonth, 2); // расчет плана на один день
            $division_result_first_month = round(($daysInMonth / 2) * $division_result_plan_day, 2); // расчет плана на первую половину месяца
            $division_result_second_month = round(($daysInMonth / 2) * $division_result_plan_day, 2); // расчет плана на вторую половину месяца

            $division_result_fact_day = 0; // фактический результат за один день 
            $calc_difference = $division_result_plan_day - $division_result_fact_day; // разница 



            $division_result_plan_day_beggin_month = 0; // выполнение плана с начала месяца за день
            $division_result_fact_day_beggin_month = 0; // выполнение фактически с начала месяца за день

            $stamping_workers_shift = 0; // штамповщики в смену

            $data_to_add[$i] = array(
                'detail' => $current_detail, // название детали
                'plan_month_tn' => $current_plan_mont_tn,  // план на месяц в тоннах 
                'division_result_plan_day' => $division_result_plan_day, // расчет плана на один день
                'division_result_fact_day' => $division_result_fact_day, //фактически выполненный план за день

                'stamping_workers_shift' => $stamping_workers_shift, // штамповщики в смену

                'division_result_plan_day_beggin_month' => $division_result_plan_day_beggin_month, // выполнение плана с начала месяца  по плану
                'division_result_fact_day_beggin_month' => $division_result_fact_day_beggin_month, // выполнение плана с начала месяца  по факту

                'calc_difference' => $calc_difference, // разница между планом и фактом

                'total_plan_day' => '',

                'division_result_first_month' => $division_result_first_month, // расчет плана на первую половину месяца
                'division_result_second_month' => $division_result_second_month, // расчет плана на вторую половину месяца
                'data' => '',
            );
           
        }



        $resultWithDates = array();

        $datesArray = explode("\n", $dates);

        foreach ($datesArray as $date) {
            // подставляет значение data в элемент массива
            foreach ($data_to_add as $item) {
                $item['data'] = $date;
                $resultWithDates[] = $item;
            }

        }

        // сортирует массив по detail
        usort($resultWithDates, function ($a, $b) {
            return $a['detail'] <=> $b['detail'];
        });
        // подставляет значение data во все элементы массива
        $resultWithDates = array_filter($resultWithDates, function ($item) {
            return $item['data'] != '';
        });


        // считаем количество уникальных деталей
        $details_values = [];

        foreach ($resultWithDates as $item) {
            $details_values[] = $item['detail'];
        }
        $unique_details_values = array_unique($details_values);
        $count_unique_details = count($unique_details_values); // считаем количество уникальных деталей

        // считаем количество планов дневных по плану
        $division_result_plan_day_values = [];

        foreach ($resultWithDates as $item) {
            $division_result_plan_day_values[] = $item['division_result_plan_day'];
        }

        $count_division_result_plan_day_values = count($division_result_plan_day_values);

        // считаем количество планов дневных
        $result = array_chunk($division_result_plan_day_values, ceil($count_division_result_plan_day_values / $count_unique_details));



        // считаем количество выполненного плана по факту 
        $division_result_fact_day_values = [];

        foreach ($resultWithDates as $item) {
            $division_result_fact_day_values[] = $item['division_result_fact_day'];
        }

        $count_division_result_fact_day_values = count($division_result_fact_day_values);

        // считаем количество планов дневных
        $result2 = array_chunk($division_result_fact_day_values, ceil($count_division_result_fact_day_values / $count_unique_details));

        $total_plan_fact_day_the_month = array(
            'total_plan_day_the_month' => $result,
            'total_plan_fact_the_month' => $result2,
        );

        $resultWithKeys = array_values($resultWithDates); // Переиндексация массива

        //   tte($total_plan_fact_day_the_month);

        //  tte($resultWithKeys);
        $json_data = json_encode($resultWithKeys, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
       

        $json_data_total_plan_fact_day_the_month = json_encode($total_plan_fact_day_the_month, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
       
        $query = "UPDATE product_schedule SET date = :date, whom = :whom, provided_whom = :provided_whom, schedule = :schedule, plan_beginning_month = :plan_beginning_month, plan_month = :plan_month WHERE id = :id";

        try {
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":date", $_POST["date"]);
            $stmt->bindParam(":whom", $_POST["agreed"]);
            $stmt->bindParam(":provided_whom", $_POST["ratify"]);
            $stmt->bindParam(":schedule", $json_data);
            $stmt->bindParam(":plan_beginning_month", $json_data_total_plan_fact_day_the_month);
            $stmt->bindParam(":plan_month", $_POST["total_plan_month_tn"]);
            $stmt->bindParam(":id", $id);

           
            $stmt->execute();

            return true; // Возвращаем true, если запрос выполнен успешно
        } catch (\PDOException $e) {
            // Обработка ошибок, например, запись в журнал или вывод сообщения об ошибке
            error_log("Ошибка при обновлении плана: " . $e->getMessage());
            return false;
        }
    }

}
