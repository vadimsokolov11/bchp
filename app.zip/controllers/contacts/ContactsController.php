<?php
namespace controllers\contacts;

class ContactsController {
    public function index() {
        include 'app/views/users_views/contacts/index.php';
    }
}
