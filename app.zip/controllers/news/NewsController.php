<?php
namespace controllers\news;

class NewsController {
    public function index() {
        include 'app/views/users_views/news/index.php';
    }
}
