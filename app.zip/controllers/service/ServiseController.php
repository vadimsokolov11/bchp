<?php
namespace controllers\service;

class ServiseController {
    public function index() {
        include 'app/views/users_views/service/index.php';
    }
}
