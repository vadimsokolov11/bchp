<?php
namespace controllers\home;

class HomeController {
    public function index() {
        include 'app/views/users_views/homeuser/index.php';
    }
}
