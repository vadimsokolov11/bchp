<?php
namespace controllers\oq;

class OqController {
    public function index() {
        include 'app/views/users_views/oq/index.php';
    }
}
