<?php
namespace controllers\about;

class AboutController {
    public function index() {
        include 'app/views/users_views/about/index.php';
    }
}
