<?php
namespace controllers\testimonial;

class TestimonialController {
    public function index() {
        include 'app/views/users_views/reviews/index.php';
    }
}
